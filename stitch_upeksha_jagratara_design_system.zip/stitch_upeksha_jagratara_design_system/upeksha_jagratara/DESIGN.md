---
name: Upeksha Jagratara
colors:
  surface: '#f9f9f7'
  surface-dim: '#dadad8'
  surface-bright: '#f9f9f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4f2'
  surface-container: '#eeeeec'
  surface-container-high: '#e8e8e6'
  surface-container-highest: '#e2e3e1'
  on-surface: '#1a1c1b'
  on-surface-variant: '#424750'
  inverse-surface: '#2f3130'
  inverse-on-surface: '#f1f1ef'
  outline: '#727781'
  outline-variant: '#c2c6d1'
  surface-tint: '#27609d'
  primary: '#003461'
  on-primary: '#ffffff'
  primary-container: '#004b87'
  on-primary-container: '#8abcff'
  inverse-primary: '#a3c9ff'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fed488'
  on-secondary-container: '#785a1a'
  tertiary: '#572500'
  on-tertiary: '#ffffff'
  tertiary-container: '#793701'
  on-tertiary-container: '#ffa46a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d3e4ff'
  primary-fixed-dim: '#a3c9ff'
  on-primary-fixed: '#001c38'
  on-primary-fixed-variant: '#004882'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#ffdbc8'
  tertiary-fixed-dim: '#ffb68b'
  on-tertiary-fixed: '#321300'
  on-tertiary-fixed-variant: '#753400'
  background: '#f9f9f7'
  on-background: '#1a1c1b'
  surface-variant: '#e2e3e1'
  dark-navy: '#001B33'
  muted-gold: '#C5A059'
  off-white: '#F8F8F6'
  deep-ocean-blue: '#004B87'
typography:
  headline-xl:
    fontFamily: IBM Plex Sans
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 36px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.4'
  headline-sm:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '500'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  headline-xl-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: '1.2'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  section-padding-desktop: 120px
  section-padding-mobile: 64px
  gutter: 24px
  margin-container: auto
  max-width-container: 1200px
---

## Brand & Style

The brand personality is **Calm yet Authoritative**, embodying the concept of "Upeksha Jagratara"—a state of tranquil alertness. It targets prospective students and parents who value discipline, tradition, and personal growth. The UI must feel grounded and professional, avoiding the frantic energy often associated with combat sports.

The design style is a blend of **Minimalism** and **Corporate Modernism**, characterized by:
- **Quiet Authority:** Large amounts of whitespace to create "breathing room" and reflect the "calm" aspect of the brand.
- **Disciplined Structure:** A clean, scannable layout that uses high-quality typography and a restrained color palette to convey reliability.
- **Traditional Accents:** Subtle, meaningful symbolic elements—thin curved lines representing waves and minimalist karambit icons—bridge the gap between ancient heritage and a modern digital presence.

## Colors

The palette is designed to evoke trust and heritage while maintaining a clean, contemporary aesthetic. 

- **Primary (Deep Ocean Blue):** Used for primary actions, links, and navigational highlights. It represents the depth and calm of the ocean.
- **Secondary/Accent (Muted Gold):** Used sparingly for thin dividers, icons, and small highlights. It signifies excellence and the value of the martial arts path.
- **Neutral/Background (Off-White):** This is the canvas of the website. It prevents the design from feeling too "heavy" or aggressive, ensuring the content remains approachable.
- **Typography (Dark Navy):** Used for all headings and body text to ensure maximum readability and a sense of serious discipline.

The default color mode is **Light**, emphasizing clarity and openness.

## Typography

The typography system uses **IBM Plex Sans** for headings to project a structured, technical, and authoritative feel that aligns with the academy's disciplined nature. **Inter** is used for body text to ensure maximum legibility across all devices.

- **Scale:** High contrast between headlines and body text helps guide the user through the single-page scroll.
- **Vertical Rhythm:** A generous line-height of 1.6 for body text ensures high readability during long-form reading about philosophy or history.
- **Mobile Adaptation:** Large display titles scale down on mobile to prevent awkward text wrapping while maintaining visual impact.

## Layout & Spacing

The design system utilizes a **Fixed Grid** approach for desktop to maintain an elegant, controlled appearance, transitioning to a **Fluid Grid** for mobile devices.

- **Whitespace Strategy:** Every section is separated by a significant vertical gap (120px on desktop) to reinforce the "Calm" brand pillar.
- **Grid:** A standard 12-column grid is used for desktop. 
    - **Desktop (>1024px):** 12 columns, 24px gutters, max-width 1200px.
    - **Tablet (768px - 1024px):** 2-column layouts for cards (Jadwal/Agenda).
    - **Mobile (<768px):** Single-column stack with 20px side margins.
- **Reflow Rules:** Cards and grid items transition from horizontal layouts (3 or 4 per row) on desktop to vertical stacks on mobile to ensure tap targets remain accessible.

## Elevation & Depth

To maintain the "Modern & Clean" aesthetic, depth is conveyed through **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows.

- **Surface Tiers:** The background is consistently `off-white`. Content cards (Jadwal, Testimoni) use a pure white background with a very subtle 1px border in a lightened navy or muted gold to separate them from the canvas.
- **Shadows:** If used, shadows must be "Ambient Shadows"—extremely soft (0% to 5% opacity), large blur radius, and no offset, creating a subtle lift rather than a harsh drop.
- **Dividers:** Use thin, curved lines (the wave motif) in `muted-gold` or `deep-ocean-blue` to transition between sections, replacing standard horizontal rules.

## Shapes

The shape language is **Soft (0.25rem)**. This slight rounding takes the edge off the "technical" typography and navy color palette, making the academy feel welcoming while remaining disciplined.

- **Primary Buttons:** Subtle rounding (4px) to maintain a professional, firm look.
- **Cards:** Use `rounded-lg` (8px) to create a gentle distinction from the background.
- **Visual Dividers:** The wave motif should be rendered as a smooth, vector bezier curve, reinforcing the "adaptation" and "fluidity" of Pencak Silat.

## Components

- **Buttons:** 
    - **Primary:** Solid `deep-ocean-blue` with white text. No gradients.
    - **Secondary/Outline:** Transparent background with a `deep-ocean-blue` 2px border.
- **Cards (Jadwal & Agenda):** White background, `rounded-lg` corners, 1px subtle border. Use a small `muted-gold` accent line at the top of the card to indicate priority.
- **Inputs:** Clean, 1px navy borders, focusing on high-contrast focus states using a gold ring.
- **Chips/Filters:** Used in the Gallery. `off-white` background for inactive states, `deep-ocean-blue` with white text for active states.
- **Icons:** Use thin-stroke (Linear) icons. The **Karambit** icon should only appear as a small decorative bullet point or footer ornament, never larger than 32px.
- **Dividers:** Implement the "Wave" divider as an SVG between the Hero and "Tentang" sections, and again before the "CTA Bergabung" section to create a cohesive flow.